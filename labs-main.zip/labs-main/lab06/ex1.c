#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void Win()
{
    printf("Well done!\n");
}

int main(int argc, char *argv[])
{
    int a = 0;
    char buffer[16];

    if(argc < 2){
        printf("Usage: %s <string>\n", argv[0]);
        exit(1);
    }
    printf("Address of a: %p\n", &a);
    printf("Address of buffer: %p\n", buffer);

    strcpy(buffer, argv[1]);
    printf("Value of a: %08x\n", a);

    if (a == 0x41424344) Win(); 
    else printf("Try again\n"); 
    return 0;
}

