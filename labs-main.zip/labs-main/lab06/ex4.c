#include <stdio.h>

int main(int argc, char * argv[])
{
    int  secret_int = 0x41424344;

    if(argc < 2) {
        printf("Usage: %s <message>\n", argv[0]); 
        return 0;
    }

    printf(argv[1]);
    return 0;
}