#include <stdio.h>
#include <string.h>

int n = 0; 

void Win1()
{
    printf("Well done! Can you get to Win2()? \n"); 
}

void Win2()
{
    printf("You did it!\n");
}

int main(int argc, char * argv[])
{
    char buf[64];

    printf("Address of n = %p\n", &n);
    printf("Enter a string: "); 
    fgets(buf, 64, stdin); 
    printf(buf); 
    printf("Value of n = %08x\n", n);
    if(n == 100) Win1();
    if(n == 3) Win2(); 
    return 0; 
}
